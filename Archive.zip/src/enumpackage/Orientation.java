package enumpackage;

/**
 * This enum represents the orientation of an image.
 */
public enum Orientation {
  Horizontal, Vertical
}
