package enumpackage;

/**
 * This enum represents the values of brightness.
 */
public enum Brightness {
  Value, Intensity, Luma
}
