package enumpackage;

/**
 * This enum represents the rgb values.
 */
public enum Component {
  Red, Green, Blue
}
