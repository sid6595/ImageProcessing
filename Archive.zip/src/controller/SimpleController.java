package controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Stack;
import java.util.function.Function;

import enumpackage.Brightness;
import enumpackage.Component;
import enumpackage.Orientation;
import controller.commands.Brighten;
import controller.commands.Flip;
import controller.commands.Load;
import controller.commands.Save;
import controller.commands.VisRGB;
import controller.commands.VisIntensity;
import model.ImageProcessorModel;
import model.ModelImpl;

/**
 * This class is the controller where all the commands are stored and where everything
 * can be run.
 */
public class SimpleController {
  /**
   * This constructor takes in a string from the user.
   *
   * @param args This argument is a string array from the user stored in scanner.
   */
  //TODO look at MarbleSolitaire and turn into controller and separate main
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    ImageProcessorModel m = new ModelImpl();
    Stack<FunctionObjects> commands = new Stack<>();

    Map<String, Function<Scanner, FunctionObjects>> knownCommands = new HashMap<>();
    knownCommands.put("brighten", (Scanner s) -> {
      return new Brighten(s.nextInt());
    });
    knownCommands.put("vertical-flip", (Scanner s) -> {
      return new Flip(Orientation.Vertical);
    });
    knownCommands.put("horizontal-flip", (Scanner s) -> {
      return new Flip(Orientation.Horizontal);
    });
    knownCommands.put("value-component", (Scanner s) -> {
      return new VisIntensity(Brightness.Value);
    });
    knownCommands.put("intensity-component", (Scanner s) -> {
      return new VisIntensity(Brightness.Intensity);
    });
    knownCommands.put("luma-component", (Scanner s) -> {
      return new VisIntensity(Brightness.Luma);
    });
    knownCommands.put("red-component", (Scanner s) -> {
      return new VisRGB(Component.Red);
    });
    knownCommands.put("green-component", (Scanner s) -> {
      return new VisRGB(Component.Green);
    });
    knownCommands.put("blue-component", (Scanner s) -> {
      return new VisRGB(Component.Blue);
    });
    knownCommands.put("save", (Scanner s) -> {
      return new Save();
    });
    knownCommands.put("load", (Scanner s) -> {
      return new Load();
    });


    while (scan.hasNext()) {
      FunctionObjects c;
      String in = scan.next();
      if (in.equalsIgnoreCase("q") || in.equalsIgnoreCase("quit")) {
        return;
      }
      Function<Scanner, FunctionObjects> cmd = knownCommands.getOrDefault(in, null);
      if (cmd == null) {
        throw new IllegalArgumentException();
      } else {
        c = cmd.apply(scan);
        String input = scan.next();
        String saveName = scan.next();
        commands.add(c);
        c.apply(m, input, saveName);
      }
    }
  }
}
