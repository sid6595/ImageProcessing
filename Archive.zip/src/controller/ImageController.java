package controller;

//TODO What goes here?
//TODO Should we actually display an image or just store the pixels?

/**
 * This interface represents where we store the methods for the controller.
 */
public interface ImageController {

}
